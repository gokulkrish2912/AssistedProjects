package assistedproject;

public class MethodsCalling {
	 public void methodDisplay() {
			System.out.println("You have called Display Method");
		 }
		 public int numberMethod() {
			 
			 int a=5;
			 return a;
		 }
		
		 public static void main(String[] args) {
			 
			 MethodsCalling obj= new MethodsCalling();
			 obj.methodDisplay();
			 
			 int result=obj.numberMethod();
			 
			 System.out.println(result);
			
		}
	}