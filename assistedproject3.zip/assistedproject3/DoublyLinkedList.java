package assistedproject3;

public class DoublyLinkedList {

	    	Ne head; 
	        class Ne 
	{ 
	        		int demodata; 
	        		Ne previous; 
	        		Ne nextone; 
	Ne(int d) 
	{ 
	      demodata = d; 
	} 
	    	}
public void push(int new_data) 
	    	{ 
	               Ne new_Node = new Ne(new_data); 
	               new_Node.nextone = head; 
	               new_Node.previous = null; 
	               if (head != null) 
	            			head.previous = new_Node; 
	               head = new_Node; 
	    	} 
	public void InsertAfter(Ne prev_Node, int new_data) 
	    	{ 
	if (prev_Node == null) 
	{ 
	            			System.out.println("The given previous node cannot be NULL "); 
	            			return; 
	        		} 	
	Ne new_node = new Ne(new_data); 
	new_node.nextone = prev_Node.nextone; 
	prev_Node.nextone = new_node; 
	new_node.previous = prev_Node; 
	if (new_node.nextone != null) 
	           	new_node.nextone.previous = new_node; 
	    	} 
	    	void append(int new_data) 
	    	{ 
	            Ne new_node = new Ne(new_data); 
	  	     	Ne last = head; 
	            new_node.nextone = null;
	            if (head == null) 
	{ 
	            			new_node.previous = null; 
	            			head = new_node; 
	            			return; 
	        		} 
	while (last.nextone != null) 
	            			last = last.nextone; 
	last.nextone = new_node; 
	new_node.previous = last; 
	} 
	public void printlist(Ne node) 
	    	{ 
	        		Ne last = null; 
	        		System.out.println("Traversal in Forward Direction : "); 
	        		while (node != null) 
	{ 
	            			System.out.print(node.demodata + " "); 
	            			last = node; 
	            			node = node.nextone; 
	        		} 
	        		System.out.println(); 
	        		System.out.println("Traversal in Reverse Direction : "); 
	        		while (last != null) 
	{ 
	            			System.out.print(last.demodata + " "); 
	            			last = last.previous; 
	        		} 
	    	}
	public static void main(String[] args) 
 {
                   DoublyLinkedList dll = new DoublyLinkedList();
	               dll.append(8); 
	               dll.push(4);
	               dll.push(2); 
	               dll.append(10); 
	               dll.InsertAfter(dll.head.nextone, 6); 
	               System.out.println("Created DoublyLinkedList is: "); 
	        	   dll.printlist(dll.head); 
	    	} 
} 
