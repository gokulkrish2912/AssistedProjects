package assistedproject3;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	 
	 public static void main(String[] args) {
	  Queue<String> Queuelist= new LinkedList<String>();
	  
	  Queuelist.add("Ironman");
	  Queuelist.add("Spiderman");
	  Queuelist.add("Thor");
	  Queuelist.add("Antman");
	  Queuelist.add("Wasp");
	  Queuelist.add("Hulk");
	  
	  System.out.println("Movie Queue is : "+Queuelist);  
	  //find head of queue
	  System.out.println("Head of the Movie Queue list : "+Queuelist.peek());
	  Queuelist.remove();  
	  System.out.println("After Removing Head Movie: "+Queuelist);  
	 }
}
