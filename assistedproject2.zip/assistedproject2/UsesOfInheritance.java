package assistedproject2;

class car{
	    public int gear; 
	    public int speed; 
	    public car(int gear, int speed) 
	    { 
	        this.gear = gear; 
	        this.speed = speed; 
	    } 
	    public void applyBrake(int decrement) 
	    { 
	        speed -= decrement; 
	    } 
	    public void speedUp(int increment) 
	    { 
	        speed += increment; 
	    }  
	    public String toString()  
	    { 
	        return("No of gears are " + gear + "\n" + "speed of car is " + speed); 
	    }  
	} 
	class tata extends car  
	{ 
	    public int seatHeight; 
	    public tata(int gear,int speed,int startHeight) 
	    {  
	        super(gear, speed); 
	        seatHeight = startHeight; 
	    }  
	    public void setHeight(int newValue) 
	    { 
	        seatHeight = newValue; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return (super.toString()+ 
	                "\nseat height is "+seatHeight + " inches"); 
	    } 
	}
	public class UsesOfInheritance  
	{ 
	    public static void main(String args[])  
	    { 
	        tata mb = new tata(6, 120, 27); 
	        System.out.println(mb.toString());
	    } 
}

