package assistedproject;

public class InnerClasses1 {
	
		 private String msg="Welcome to PVR cinemas"; 
		 
		 class Inner{  
		  void hello(){System.out.println(msg+", Enjoy your movie");}  
		 }  


		public static void main(String[] args) {

			InnerClasses1 obj=new InnerClasses1();
			InnerClasses1.Inner in=obj.new Inner();  
			in.hello();  
		}
	}


