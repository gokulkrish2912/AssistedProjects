package assistedproject4;

import java.util.Arrays;

public class ExponentialSearch {

	public static  void main(String[] args){

	    int[] a = {11,22,33,44,55};
	    int Len= a.length;
	    int Val = 44;
	    int Output = expSearch(a,Len,Val);

	    if(Output<0){

	       System.out.println( "Not an element of the array");

	    }else {

	        System.out.println( "The array contains the element at index :"+Output);
	    }

	        }

	        public static int expSearch(int[] a ,int Len , int Val ){

	        if(a[0]==Val){
	            return 0;
	            }
	        int i=1;
	        while(i<Len && a[i]<=Val){

	            i=i*2;
	        }
	        return Arrays.binarySearch(a,i/2,Math.min(i,Len),Val);
	        }


}

