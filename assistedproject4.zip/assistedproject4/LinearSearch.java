package assistedproject4;

import java.util.Scanner;

public class LinearSearch {

	    public static void main(String[] args){

	        int[] a = {11,22,33,44,55};

	        Scanner scan = new Scanner(System.in);
	        System.out.println("Enter the search element here :");
	        int Search = scan.nextInt();
	            int res = (int) linearing(a,Search);

	            if(res==-1){

	                System.out.println("Not an element of the array");
	            } else {

	                System.out.println("Element found at "+res+" and the search key is "+a[res]);
	            }


	        }

	public static int linearing(int a[], int b) {

	    int alength = a.length;
	    for (int i = 0; i < alength - 1; i++) {

	        if (a[i] == b) {

	            return i;

	         }
	     }

	            return -1;

	   }

}

