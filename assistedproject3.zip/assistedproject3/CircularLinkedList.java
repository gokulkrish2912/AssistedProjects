package assistedproject3;

public class CircularLinkedList {

	    	static class Ne 
	    	{ 
	  		int demodata; 
	        		        Ne nextone; 
	                    	Ne(int d) 
	        		{ 
	            			demodata = d; 
	            			nextone = null; 
	        		} 
	}
	                        Ne head; 
	CircularLinkedList()   
	{ 
	                        head = null; 
	} 
	void SortInsert(Ne new_node) 
	    	{ 
	        		        Ne current = head; 
	if (current == null) 
	        		{ 
	            			new_node.nextone = new_node; 
	            			head = new_node; 
	  		        } 
	else if (current.demodata >= new_node.demodata) 
	        		{ 
	while (current.nextone != head) 
	                		current = current.nextone; 
	  		 	            current.nextone = new_node; 
	            			new_node.nextone = head; 
	            			head = new_node; 
	        		} 
	        		else
	        		{
	while (current.nextone != head && current.nextone.demodata < new_node.demodata) 
	                		current = current.nextone; 
	  			            new_node.nextone = current.nextone; 
	            			current.nextone = new_node; 
	        		} 
		}
	void printList() 
	    	{ 
	        		if (head != null) 
	       		{ 
	            			Ne temp = head; 
	            			do
	           			{ 
	                		System.out.print(temp.demodata + " "); 
	                		temp = temp.nextone; 
	            		}  while (temp != head); 
	        		} 
	    	}
	public static void main(String[] args) 
	    	{ 
		                   CircularLinkedList list = new CircularLinkedList(); 
	        		       int arr[] = new int[] {15, 84, 1, 33, 69, 7}; 
	        		       Ne temp = null; 
	        		       for (int i = 0; i < 6; i++) 
	        		{ 
	           			   temp = new Ne(arr[i]); 
	            	    	list.SortInsert(temp); 
	        		} 
	                       list.printList(); 
	    	}		  
}

