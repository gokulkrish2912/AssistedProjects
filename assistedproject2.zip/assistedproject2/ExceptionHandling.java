package assistedproject2;

class ExceptionDemo extends Exception{
	   String str1;
	   ExceptionDemo(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("ExceptionDemo Occurred: "+str1) ;
	   }
	}
public class ExceptionHandling {
		   public static void main(String args[]){
			try{
				System.out.println("Starting to try Java");
				// I'm throwing the custom exception using throw
				throw new ExceptionDemo("This is My error Message");
			}
			catch(ExceptionDemo exp){
				System.out.println("Learned Java") ;
				System.out.println(exp) ;
			}
		   }
}

