package assistedproject3;

import java.io.*; 

public class SinglyLinkedList {

	Ne head;
	    	static class Ne 
	{ 
	        		int demodata; 
	        		Ne next1; 
	        		Ne(int d) 
	        		{ 
	            			demodata = d; 
	            			next1 = null; 
	        		} 
	    	} 

	    	public static SinglyLinkedList insert(SinglyLinkedList list, int demodata) 
	    	{ 
	        		Ne NewNode = new Ne(demodata); 
	        		NewNode.next1 = null; 
	        		if (list.head == null) 
	{ 
	            			list.head = NewNode; 
	        		} 
	        		else 
	{ 
	            			Ne lastone = list.head; 
	            			while (lastone.next1 != null) 
	{ 
	                			lastone = lastone.next1; 
	            			} 
	            			lastone.next1 = NewNode; 
	        		} 
	        		return list; 
	    	} 
	   	public static void printList(SinglyLinkedList list) 
	    	{	 
	        		Ne CurrNode = list.head; 
	        		System.out.print("LinkedList: "); 
	        		while (CurrNode != null) 
	{ 
	            			System.out.print(CurrNode.demodata + " "); 
	            			CurrNode = CurrNode.next1; 
	        		} 
	        		System.out.println(); 
	    	} 
	    	public static SinglyLinkedList deleteByKey(SinglyLinkedList list, int k) 
	    	{ 
	        		Ne CurrNode = list.head, prev = null; 
	        		if (CurrNode != null && CurrNode.demodata == k) 
	{ 
	            			list.head = CurrNode.next1; 
	            			System.out.println(k + " found and deleted"); 
	            			return list; 
	        		} 
	        		while (CurrNode != null && CurrNode.demodata != k) 
	{ 
	            			prev = CurrNode; 
	            			CurrNode = CurrNode.next1; 
	        		} 
	        		if (CurrNode != null) 
	{ 
	            			prev.next1 = CurrNode.next1; 
	            			System.out.println(k + " found and deleted"); 
	        		} 
	        		if (CurrNode == null) 
	{ 
	            			System.out.println(k + " not found"); 
	        		} 
	        		return list; 
	    	} 
	    	public static void main(String[] args) 
	    	{ 
	    		    SinglyLinkedList list = new SinglyLinkedList(); 
	        		list = insert(list, 2); 
	        		list = insert(list, 4); 
	        		list = insert(list, 6); 
	        		list = insert(list, 8); 
	        		list = insert(list, 10); 
	        		list = insert(list, 12); 
	        		list = insert(list, 14); 
	        		list = insert(list, 16); 

	        		printList(list); 
	        		deleteByKey(list, 6); 
	        		printList(list); 
	        		deleteByKey(list, 16); 
	        		printList(list); 
	       		    deleteByKey(list, 11); 
	        		printList(list); 
	    	}
}
