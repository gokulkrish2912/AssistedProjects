package assistedproject4;

public class BinarySearch {

	    public static  void main(String[] args){


	        int[] a = {11,22,33,44,55};
	        int SearchKey = 33;
	        int ALen = a.length;
	        binarySearch(a,0,SearchKey,ALen);
	    }

	public static void binarySearch(int[] a, int Start, int SearchKey, int ALen){

	        int MidVal = (Start+ALen)/2;
	        while(Start<=ALen){

	            if(a[MidVal]<SearchKey){

	                Start = MidVal + 1;
	            } else if(a[MidVal]==SearchKey){
	                System.out.println("The element is found at index :"+MidVal);
	                break;
	            }else {

	                ALen = MidVal - 1;
	            }
	            MidVal = (Start+ALen)/2;
	        }
	            if(Start>ALen){

	                System.out.println("Element is not found");
	            }

	}

}

