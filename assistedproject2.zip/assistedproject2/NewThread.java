package assistedproject2;

public class NewThread extends Thread {
		   //method over loading
		  public void run() {
		   System.out.println("thread Started");
		  }
		  
		  public static void main(String[] args) {
		   
		   NewThread t1= new NewThread();
		   NewThread t2 = new  NewThread();
		   
		   t1.start();
		   t2.start();
		  }

}

