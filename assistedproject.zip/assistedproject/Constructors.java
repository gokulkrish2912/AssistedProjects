package assistedproject;

public class Constructors {
		int Id;
		String Name;
		
		//default constructor
		public Constructors() {
			Id=9876;
			Name="Mani";
		}
		
		//parametrized constructor
		public Constructors(int Id,String Name) {
			this.Id=Id;
			this.Name=Name;
		}
		
		public void display() {
			System.out.println("Id: "+Id);
			System.out.println("Name: "+Name);
			System.out.println();
			
		}
		
		public static void main(String[] args) {
			
			Constructors s= new Constructors();
			Constructors s1= new Constructors(10, "Pranav"); 

			//calling default constructor
			s.display();
			//parametrized constructor
			s1.display();
			
		}
		
	}

