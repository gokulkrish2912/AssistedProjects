package assistedproject4;

public class QuickSort {
	   
	    int part(int a[], int Low, int High)
	    {
	        int pi = a[High];
	        int i = (Low-1); 
	        for (int j=Low; j<High; j++)
	        { 
	            if (a[j] <= pi)
	            {
	                i++;

	                int Temp = a[i];
	                a[i] = a[j];
	                a[j] = Temp;
	            }
	        }

	        int Temp = a[i+1];
	        a[i+1] = a[High];
	        a[High] = Temp;

	        return i+1;
	    }



	    void sort(int a[], int Low, int High)
	    {
	        if (Low < High)
	        {

	            int pi = part(a, Low, High);

	            
	            sort(a, Low, pi-1);
	            sort(a, pi+1, High);
	        }
	    }
	    static void printArray(int a[])
	    {
	        int Number = a.length;
	        for (int i=0; i<Number; ++i)
	            System.out.print(a[i]+" ");
	        System.out.println();
	    }

	    public static void main(String args[])
	    {
	        int a[] = {44, 11, 55, 33, 22};
	        int n = a.length;

	        QuickSort ob = new QuickSort();
	        ob.sort(a, 0, n-1);

	        System.out.println("Sorted Array is:");
	        printArray(a);
	    }
}

