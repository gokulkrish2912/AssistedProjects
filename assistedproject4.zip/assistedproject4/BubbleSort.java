package assistedproject4;

public class BubbleSort {

	    public static void main(String[] args){

	     int[] a= {33,11,55,22,44};
	     bubbleSort(a);
	     for(int i=0;i<a.length;i++){

	        System.out.println(a[i]);
	        }
	    }

	    public static void bubbleSort(int[] a){
	        int Length = a.length;
	        int Temp = 0;
	        for(int i=0;i<Length;i++){
	            for (int j=1;j<(Length);j++){
	                if(a[j-1]>a[j]){
	                Temp = a[j-1];
	                a[j-1]= a[j];
	                a[j]= Temp;

	                }


	            }

	        }

	    }

	}
