package assistedproject4;

public class SelectionSort {

	    public static void main(String[] args) {

	    int[] a = {44,11,33,22,55};
	    int Len = a.length;
	    selectionSort(a);
	    System.out.println("The sorted elements are:");
	    for(int i:a){

	        System.out.println(i);
	         }
	     }

	    public static void selectionSort(int[] a){

	        for(int i=0;i<a.length-1;i++){

	            int IndexNum =i;
	            for(int j=i+1;j<a.length;j++){
	                if(a[j]<a[IndexNum]){

	                    IndexNum =j;
	                }

	            }
	            int SmallNum = a[IndexNum];
	            a[IndexNum]= a[i];
	            a[i]= SmallNum;
	        }

	    }
	}
