package assistedproject2;

class MyException extends Exception 
{ 
    public MyException(String s) 
    { 
        super(s); 
    } 
} 
public class CustomExceptions {
	    public static void main(String args[]) 
	    { 
	        try
	        { 
	            throw new MyException("HI"); 
	        } 
	        catch (MyException ex) 
	        { 
	            System.out.println("BYE"); 
	            System.out.println(ex.getMessage()); 
	        } 
	    } 
}

