package assistedproject;

public class implicittypecast {
public static void main(String[] args) {
	
		System.out.println("Type casting:implicit");
		char d1='A';
		System.out.println("Value of d1: "+d1);
		
		int d2=d1;
		System.out.println("Value of d2: "+d2);
		
		float d3=d1;
		System.out.println("Value of d3: "+d3);
		
		long d4=d1;
		System.out.println("Value of d4: "+d4);
		
		double d5=d1;
		System.out.println("Value of d5: "+d5);
		
				
		System.out.println("\n");
		
		System.out.println("Type casting:explicit");
	
		double x=45.5;
		int y=(int)x;
		System.out.println("Value of x: "+x);
		System.out.println("Value of y: "+y);
		
	}
}
