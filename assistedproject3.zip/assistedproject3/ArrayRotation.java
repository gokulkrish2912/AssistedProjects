package assistedproject3;

class RotArr { 
	public void rotate(int[] number, int x) {
	    		if(x > number.length) 
	       			x=x%number.length;
	 		int[] res = new int[number.length];
	 		for(int i=0; i < x; i++){
	        			res[i] = number[number.length-x+i];
	 		}
	 		int j=0;
	    		for(int i=x; i<number.length; i++){
	        			res[i] = number[j];
	j++;
	    		}
	 		System.arraycopy( res, 0, number, 0, number.length );
	}
	} 
public class ArrayRotation {
	
			public static void main(String[] args) {
			        	RotArr rn = new RotArr();
		        		int y[] = { 3, 7, 5, 9, 11, 13, 17 }; 
		        		rn.rotate(y, 5); 
		        		for(int i=0;i<y.length;i++){
		            			System.out.print(y[i]+" ");
		        		}
			}
}

