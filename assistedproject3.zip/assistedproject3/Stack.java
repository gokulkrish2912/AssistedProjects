package assistedproject3;

public class Stack {
	
	    	static final int MAX = 1000; 
	    	int t; 
	    	int arr[] = new int[MAX];  
	  	boolean isEmpty() 
	    	{ 
	        		return (t < 0); 
	    	} 
	    	Stack() 
	    	{ 
	        		t = -1; 
	    	} 
	  	boolean push(int k) 
	    	{ 
	        		if (t >= (MAX-1)) 
	        		{ 
	            			System.out.println("Stack is Overflow"); 
	            			return false; 
	        		} 
	        		else
	        		{ 
	            			arr[++t] = k; 
	            			System.out.println(k + " Pushed into stack"); 
	            			return true; 
	        		} 
	    	} 
	int pop() 
	    	{ 
	        		if (t < 0) 
	        		{ 
	            			System.out.println("Stack Underflow"); 
	            			return 0; 
	        		} 
	        		else
	        		{ 
	            			int x = arr[t--]; 
	            			return x; 
	        		} 
	    	} 
	    
	    	public static void main(String args[])
	{
	        		Stack sas = new Stack(); 
	        		sas.push(12); 
	        		sas.push(29); 
	        		sas.push(34); 
	        		System.out.println(sas.pop() + " Popped from stack"); 
	    	}
} 
