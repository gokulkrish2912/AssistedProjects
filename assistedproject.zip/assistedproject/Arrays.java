package assistedproject;

public class Arrays {
	
		public static void main(String[] args) {

		//single-dimensional array
		int z[]= {1,2,3,4,5};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array z: "+z[i]);
		}


		//multidimensional array
		int[][] x = {
		            {2, 4, 6, 8}, 
		            {3, 6, 9} };
		      
		      System.out.println("\nLength of row 1: " + x[0].length);
		      }
		}
