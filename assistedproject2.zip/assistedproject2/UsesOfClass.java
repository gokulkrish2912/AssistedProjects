package assistedproject2;

public class UsesOfClass {
	    String title; 
	    String artist; 
	    int screen; 
	    String director; 
        public UsesOfClass(String title, String artist, int screen, String director) 
	    { 
	        this.title = title; 
	        this.artist = artist; 
	        this.screen = screen; 
	        this.director = director; 
	    } 
	    public String getTitle() 
	    { 
	        return title; 
	    } 
	    public String getArtist() 
	    { 
	        return artist; 
	    } 
	    public int getScreen() 
	    { 
	        return screen; 
	    } 
	    public String getDirector() 
	    { 
	        return director; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return("The movie name is "+ this.getTitle()+ " acted by " + this.getArtist()+ " running in screen "+ this.getScreen()+ " directed by " + this.getDirector() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	    	UsesOfClass vikram = new UsesOfClass("Vikram","Kamal hasan", 2, "Lokesh Kanagaraj"); 
	        System.out.println(vikram.toString()); 
	    } 
}

