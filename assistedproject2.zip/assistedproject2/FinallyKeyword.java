package assistedproject2;

public class FinallyKeyword {
    public static void main(String[] args)
    {
        int x=20,y=0,z=0;
        try
        {
            z = x / y;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\n\tThe result is : " + z);
        }
    }
}
