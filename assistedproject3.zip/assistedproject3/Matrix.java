package assistedproject3;

public class Matrix {

	public static void main(String[] args) 
	{
	       		    int Row1 = 2, Column1 = 3;
	        		int Row2 = 3, Column2 = 2;
	        		int[][] FirstMatrix = { {1, 2, -3}, {-3, 2, 1} };
	        		int[][] SecondMatrix = { {4, 8}, {-7, -9}, {0, 5} };
	int[][] Product = multiplyMatrices(FirstMatrix, SecondMatrix, Row1, Column1, Column2);
	displayProduct(Product);
	    	}

	public static int[][] multiplyMatrices(int[][] FirstMatrix, int[][] SecondMatrix, int Row1, int Column1, int Column2) 
	{
	        		int[][] Product = new int[Row1][Column2];
	        		for(int i = 0; i < Row1; i++) 
	{
	            			for (int j = 0; j < Column2; j++) 
	{
	                			for (int k = 0; k < Column1; k++) 
	{
	                    				Product[i][j] += FirstMatrix[i][k] * SecondMatrix[k][j];
	                			}
	            			}
	       	 	}
	return Product;
	    	}
	public static void displayProduct(int[][] Product) 
	{
	        		System.out.println("Product : ");
	        		for(int[] row : Product) 
	{
	            			for (int column : row) 
	{
	                			System.out.print(column + "    ");
	            			}
	            			System.out.println();
	        		}
	    	}
}

