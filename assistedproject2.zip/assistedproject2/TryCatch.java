package assistedproject2;

public class TryCatch {
	    public static void main(String args[]) 
	    {
	        int[] array = new int[5];
	        try 
	        {
	            array[7] = 5;
	        }
	        catch (ArrayIndexOutOfBoundsException e) 
	        {
	            System.out.println("Welcome to Java!"); 
	        }
	        finally 
	        {
	            System.out.println("Your level of learning is " + array.length);
	        }
	    }
}
