package assistedproject2;

public class UsesOfPolymorphism {
	
	    public int sum(int a, int b) 
	    { 
	        return (a + b); 
	    } 
	    public int sum(int a, int b, int c) 
	    { 
	        return (a + b + c); 
	    } 
	    public double sum(double a, double b) 
	    { 
	        return (a + b); 
	    } 
	    public static void main(String args[]) 
	    { 
	    	UsesOfPolymorphism s = new UsesOfPolymorphism(); 
	        System.out.println(s.sum(5, 7)); 
	        System.out.println(s.sum(11, 17, 21)); 
	        System.out.println(s.sum(25.5, 32.5)); 
	    } 
	}

