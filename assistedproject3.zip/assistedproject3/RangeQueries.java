package assistedproject3;

public class RangeQueries {

	    static int a = 12;
	    static int b = 1000; 
	    static long tab[][] = new long[b][a + 1]; 
	    static void SparseTable(int r[], int n) 
	    { 
	        for (int i = 0; i < n; i++) 
	            tab[i][0] = r[i]; 
	        for (int j = 1; j <= a; j++) 
	            for (int i = 0; i <= n - (1 << j); i++) 
	                tab[i][j] = tab[i][j - 1] + tab[i + (1 << (j - 1))][j - 1]; 
	    } 
	    static long query(int L, int R) 
	    {
	        long ans = 0; 
	        for (int j = a; j >= 0; j--)  
	        { 
	            if (L + (1 << j) - 1 <= R)  
	            { 
	                ans = ans + tab[L][j];
	                L += 1 << j; 
	            } 
	        } 
	        return ans; 
	    }
	    public static void main(String args[]) 
	    { 
	        int r[] = { 4, 8, 9, 2, 6, 3 }; 
	        int n = r.length; 
	        SparseTable(r, n); 
	        System.out.println(query(0, 4)); 
	        System.out.println(query(1, 6)); 
	        System.out.println(query(3, 5)); 
	    } 
}

