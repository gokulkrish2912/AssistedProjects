package assistedproject2;

public class ThrowsKeyword {
        void Division() throws ArithmeticException
        {
            int x=15,y=0,z;
            z = x / y;
            System.out.print("\n\tThe result is : " + z);
        }
         public static void main(String[] args)
        {
        	ThrowsKeyword T = new ThrowsKeyword();
             try
            {
                T.Division();
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }
            System.out.print("\n\tEnd of program.");
        }
}

