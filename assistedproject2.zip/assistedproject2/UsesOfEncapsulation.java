package assistedproject2;

class Encapsulate 
{ 
    private String StudentName;  
    private int id;
    public int getid()  
    { 
      return id; 
    } 
    public String getName()  
    { 
      return StudentName; 
    }  
    public void setAge( int newid) 
    { 
      id = newid; 
    } 
    public void setName(String newStudentName) 
    { 
      StudentName = newStudentName; 
    } 
}

public class UsesOfEncapsulation {
	
	    public static void main (String[] args)  
	    { 
	        Encapsulate object = new Encapsulate(); 
	        object.setName("Sriram"); 
	        object.setAge(21);  
	        System.out.println("My Name : " + object.getName()); 
	        System.out.println("My Id : " + object.getid());     
	    }
}

