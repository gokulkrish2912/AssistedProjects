package assistedproject3;

class Small 
{ 
int Smallest(int a[], int b, int c, int d) 
    	{ 
             		if (d > 0 && d <= c - b + 1) 
        		{ 
            			int p = randomPartition(a, b, c); 
            			if (p-b == d-1) 
                			return a[p]; 
            			if (p-b > d-1) 
                			return Smallest(a, b, p-1, d); 
            			return Smallest(a, p+1, c, d-p+b-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    void swap(int a[], int i, int j) 
    { 
        int temp = a[i]; 
        a[i] = a[j]; 
        a[j] = temp; 
    } 
    int partition(int a[], int b, int c) 
    { 
        int x = a[c], i = b; 
        for (int j = b; j <= c - 1; j++) 
        { 
            if (a[j] <= x) 
            { 
                swap(a, i, j); 
                i++; 
            } 
        } 
        swap(a, i, c); 
        return i; 
    } 
    int randomPartition(int a[], int b, int c) 
    { 
        int n = c-b+1; 
        int pivoted = (int)(Math.random()) * (n-1); 
        swap(a, b + pivoted, c); 
        return partition(a, b, c); 
    } 
}  
public class OrderStatistics {

		public static void main(String[] args) {
			Small object = new Small(); 
	        int a[] = {11, 6, 4, 1, 10, 17, 21}; 
	        int n = a.length,d = 4; 
	        System.out.println("Smallest element is "+ object.Smallest(a, 0, n-1, d)); 
	    }
}

