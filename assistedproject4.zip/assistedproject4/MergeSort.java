package assistedproject4;

public class MergeSort {

	    
	    void merge(int a[], int l, int m, int r)
	    {
	        
	        int Number1 = m - l + 1;
	        int Number2 = r - m;

	        /* Create temp arrays */
	        int L[] = new int [Number1];
	        int R[] = new int [Number2];

	        /*Copy data to temp arrays*/
	        for (int i=0; i<Number1; ++i)
	            L[i] = a[l + i];
	        for (int j=0; j<Number2; ++j)
	            R[j] = a[m + 1+ j];



	        int i = 0, j = 0;

	                int k = l;
	        while (i < Number1 && j < Number2)
	        {
	            if (L[i] <= R[j])
	            {
	                a[k] = L[i];
	                i++;
	            }
	            else
	            {
	                a[k] = R[j];
	                j++;
	            }
	            k++;
	        }
	        while (i < Number1)
	        {
	            a[k] = L[i];
	            i++;
	            k++;
	        }

	        
	        while (j < Number2)
	        {
	            a[k] = R[j];
	            j++;
	            k++;
	        }
	    }
	    void sort(int a[], int l, int r)
	    {
	        if (l < r)
	        {
	            
	            int m = (l+r)/2;

	            
	            sort(a, l, m);
	            sort(a , m+1, r);

	            
	            merge(a, l, m, r);
	        }
	    }

	        static void printArray(int a[])
	    {
	        int n = a.length;
	        for (int i=0; i<n; ++i)
	            System.out.print(a[i] + " ");
	        System.out.println();
	    }

	    // Driver method
	    public static void main(String args[])
	    {
	        int a[] = {22, 55, 33, 44, 11};

	        System.out.println("Given Array :");
	        printArray(a);

	        MergeSort ob = new MergeSort();
	        ob.sort(a, 0, a.length-1);

	        System.out.println("\nSorted array :");
	        printArray(a);
	    }
	}
