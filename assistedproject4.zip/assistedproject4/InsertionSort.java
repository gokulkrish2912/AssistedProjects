package assistedproject4;

public class InsertionSort {

	    public static  void main(String[] args){

	        int[] a = {33,55,11,22,44};
	        insertionSort(a);
	        for(int i=0;i<a.length;i++){

	            System.out.println(a[i]);

	        }
	     }
	    public static void insertionSort(int[] a){

	    int Length = a.length;
	    for(int j=1;j<Length;j++){
	    int SearchKey = a[j];
	    int i=j-1;
	    while ((i>-1) && (a[i]>SearchKey)){

	        a[i+1]=a[i];
	        i--;
	    }
	    a[i+1]=SearchKey;
	         }

	    }
	}

